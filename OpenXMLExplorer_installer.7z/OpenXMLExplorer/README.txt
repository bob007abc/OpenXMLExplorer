Install:
Please open "Command Prompt (Admin)" and run "install.bat";

Uninstall:
Please open "Command Prompt (Admin)" and run "uninstall.bat";